#ifndef KERNELS_H_
#define KERNELS_H_

void bf(unsigned char* input_image, unsigned char* output_image, int width, int height, int fsize, float sigmaR, float sigmaD); // Skal med

void bfConst (unsigned char* input_image, unsigned char* output_image, int width, int height, int fsize, float sigmaR, float sigmaD); // Skal med

void bfTex (unsigned char* input_image, unsigned char* output_image, int width, int height, int fsize, float sigmaR, float sigmaD); // Skal med

void bfTex2D (unsigned char* input_image, unsigned char* output_image, int width, int height, int fsize, float sigmaR, float sigmaD); // Skal med

void bfCPU (unsigned char* input_image, unsigned char* output_image, int width, int height, int fsize, float sigmaR, float sigmaD); // Skal med


#endif
