#! /bin/bash

rm bilateralfilter
rm kernels.o
nvcc -c kernels.cu
nvcc -ccbin g++ -Xcompiler "-std=c++11" kernels.o main.cpp lodepng.cpp helpers.cpp Tester.cpp -lcuda -lcudart -o bilateralfilter
