#ifndef TESTER_HPP_
#define TESTER_HPP_

#include <iostream>
#include <string>
#include <vector>
#include "lodepng.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include "kernels.h"
#include "Timer.hpp"


class Tester{
    public:
        Tester();
        void run();


};


#endif
