#include "Tester.hpp"
#include <functional>

Tester::Tester(){}


unsigned char* inputImage(std::vector<unsigned char> in_image) {
    unsigned char* input_image = new unsigned char[(in_image.size()*3)/4];
    int where = 0;
    for(int i = 0; i < in_image.size(); ++i) {
       if((i+1) % 4 != 0) {
           input_image[where] = in_image.at(i);
           where++;
       }
    }
    return input_image;
}


std::chrono::milliseconds
time(std::function<void(unsigned char*, unsigned char*, int, int, int, float, float)> filter, unsigned char* input, unsigned char* output, int width, int height, int halfsize, float sigmaR, float sigmaD, int launch) {
    Timer t;
    t.start();
    filter(input,output,width,height,halfsize,sigmaR,sigmaD);
    t.stop();
    // Are we in warmup mode? 
    if(launch == 0) {
        return std::chrono::milliseconds(0);
    }
    return t.duration();
}


void
Tester::run() {

    std::vector<unsigned char> in_image;
    unsigned int width, height;
    unsigned error = lodepng::decode(in_image, width, height, "chess512.png");
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
    unsigned char* chess512 = inputImage(in_image);
    std::cout << "chess512.png loaded" << std::endl;

    in_image.clear();
    error = lodepng::decode(in_image, width, height, "chess1024.png");
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
    unsigned char* chess1024 = inputImage(in_image);
    std::cout << "chess1024.png loaded" << std::endl;


    in_image.clear();
    error = lodepng::decode(in_image, width, height, "chess1536.png");
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
    unsigned char* chess1536 = inputImage(in_image);
    std::cout << "chess1536.png loaded" << std::endl;


    in_image.clear();
    error = lodepng::decode(in_image, width, height, "chess2048.png");
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
    unsigned char* chess2048 = inputImage(in_image);
    std::cout << "chess2048.png loaded" << std::endl;

    in_image.clear();
    error = lodepng::decode(in_image, width, height, "chess2560.png");
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
    unsigned char* chess2560 = inputImage(in_image);
    std::cout << "chess2560.png loaded" << std::endl;

    std::vector<unsigned char*> chesss = {chess512, chess1024, chess1536, chess2048, chess2560};
    std::vector<unsigned int> sizes = {512, 1024, 1536, 2048, 2560};

    unsigned char* output = new unsigned char[2560*2560*3];
    std::function<void(unsigned char*, unsigned char*, int, int, int, float, float)> func;
    std::vector<std::chrono::milliseconds> m1,m2,m3,m4,m5;
    for(size_t i = 0; i < chesss.size(); ++i) {
        m1.push_back(std::chrono::milliseconds(0));
        m2.push_back(std::chrono::milliseconds(0));
        m3.push_back(std::chrono::milliseconds(0));
        m4.push_back(std::chrono::milliseconds(0));
        m5.push_back(std::chrono::milliseconds(0));


    }

    const int filtersize = 10;
    int repsize = 10;
    for(int REPS = 0; REPS < repsize; ++REPS) {
        for(size_t i = 0; i < chesss.size(); ++i) {
            func = bf;
            m1.at(i) += time(func, chesss.at(i), output, sizes.at(i), sizes.at(i), filtersize,10,5,REPS);
            func = bfConst;
            m2.at(i) += time(func, chesss.at(i), output, sizes.at(i), sizes.at(i), filtersize,10,5,REPS);
            func = bfTex2D;
            m3.at(i) += time(func, chesss.at(i), output, sizes.at(i), sizes.at(i), filtersize,10,5,REPS);
            func = bfTex;
            m4.at(i) += time(func, chesss.at(i), output, sizes.at(i), sizes.at(i), filtersize,10,5,REPS);
            // We don't really care about this 
            //func = bfCPU;
            //m5.at(i) += time(func, chesss.at(i), output, sizes.at(i), sizes.at(i), filtersize,10,5,REPS);

        }
    }
    repsize--;
    std::cout << "bf stats: " << std::endl;
    for(size_t i = 0; i < m1.size(); ++i) {
        std::cout << sizes.at(i) << ": " << m1.at(i).count()/repsize << std::endl;
    }

    std::cout << "bfConst stats: " << std::endl;
    for(size_t i = 0; i < m2.size(); ++i) {
        std::cout << sizes.at(i) << ": " << m2.at(i).count()/repsize << std::endl;
    }

    std::cout << "bfTex2D stats: " << std::endl;
    for(size_t i = 0; i < m3.size(); ++i) {
        std::cout << sizes.at(i) << ": " << m3.at(i).count()/repsize << std::endl;
    }
    
    std::cout << "bfTex stats: " << std::endl;
    for(size_t i = 0; i < m4.size(); ++i) {
        std::cout << sizes.at(i) << ": " << m4.at(i).count()/repsize << std::endl;
    }
    
    std::cout << "CPU stats: " << std::endl;
    for(size_t i = 0; i < m5.size(); ++i) {
        std::cout << sizes.at(i) << ": " << m5.at(i).count()/repsize << std::endl;
    }
    
    for(unsigned char* chess: chesss) {
        delete[] chess;
    }

}

