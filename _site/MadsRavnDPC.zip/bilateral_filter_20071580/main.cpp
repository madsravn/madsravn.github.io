#include <iostream>
#include <cstdlib>
#include "lodepng.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include "kernels.h"
#include "Tester.hpp"
#include <functional>


int main(int argc, char** argv) {
        if(argc == 1) {
        Tester test;
        test.run();
        return 0;
    } else if(argc != 7) {
        // sigma_r is range value-wise, while sigma_d is distance
        // sigma_d is for 2D gaussian
        std::cout << "Run with input_file output_file filter_size sigma_R sigma_D filter_number" << std::endl;
        std::cout << "Choices of filters are 1) bf, 2) bfConst, 3) bfTex2D, 4) bfCPU 5) bfTex" << std::endl;
        std::cout << std::endl << "Or run without arguments to run the tests. Require certain images." << std::endl;
        return 0;
    }

    // Read the arguments
    const char* input_file = argv[1];
    const char* output_file = argv[2];
    const int fsize = atoi(argv[3]);
    const float sigmaR = atof(argv[4]);
    const float sigmaD = atof(argv[5]);
    const int filterchosen = atoi(argv[6])-1;

    std::vector<std::function<void(unsigned char*, unsigned char*, int, int, int, float, float)>> functions = {bf, bfConst, bfTex2D, bfCPU, bfTex};

    if(!(filterchosen < functions.size())) {
        return 0;
    }

    std::vector<unsigned char> in_image;
    unsigned int width, height;

    // Load the data
    unsigned error = lodepng::decode(in_image, width, height, input_file);
    if(error) std::cout << "decoder error " << error << ": " << lodepng_error_text(error) << std::endl;

    // Prepare the data
    unsigned char* input_image = new unsigned char[(in_image.size()*3)/4];
    unsigned char* output_image = new unsigned char[(in_image.size()*3)/4];
    int where = 0;
    for(int i = 0; i < in_image.size(); ++i) {
       if((i+1) % 4 != 0) {
           input_image[where] = in_image.at(i);
           output_image[where] = 255;
           where++;
       }
    }

    // Run the filter on it
    auto func = functions.at(filterchosen);
    func(input_image, output_image, width, height, fsize, sigmaR, sigmaD ); 

    // Prepare data for output
    std::vector<unsigned char> out_image;
    for(int i = 0; i < in_image.size(); ++i) {
        out_image.push_back(output_image[i]);
        if((i+1) % 3 == 0) {
            out_image.push_back(255);
        }
    }
    
    // Output the data
    error = lodepng::encode(output_file, out_image, width, height);

    //if there's an error, display it
    if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;

    delete[] input_image;
    delete[] output_image;
    return 0;

}



