#! /bin/bash

convert chess512.png -resize 1024x1024 chess1024.png

convert chess512.png -resize 1536x1536 chess1536.png

convert chess512.png -resize 2048x2048 chess2048.png

convert chess512.png -resize 2560x2560 chess2560.png

