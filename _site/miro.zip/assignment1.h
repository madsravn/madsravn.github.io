void makeTeapotScene();
void makeBunny1Scene();
void makeBunny20Scene();
void makeSponzaScene();
