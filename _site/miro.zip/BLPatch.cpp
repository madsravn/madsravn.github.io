#include "BLPatch.h"
#include "Ray.h"
#include "Console.h"

BLPatch::BLPatch()
{
}

BLPatch::~BLPatch()
{
}

void
BLPatch::renderGL()
{

}

bool
BLPatch::intersect(HitInfo& result, const Ray& ray,
                   float tMin, float tMax)
{
    return false;
}

Vector3
BLPatch::getCenter() {
    Vector3 vec;
    return vec;
}
