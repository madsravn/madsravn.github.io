class X {
    private: 
        int y;
    public:
        int GetY() { return y; }
};

class Y {
    public:
        int y;
        int GetY() { return y; } // Match this one only. 
};

class Z {
    protected:
        int y;
    public:
        int GetY() { return y; }
};


int main() {
    X x;
    return 0;
}
