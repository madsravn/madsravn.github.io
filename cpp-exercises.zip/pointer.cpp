int main() {
    int *a;
    if(a == 0) { // Match this one only. Use integerLiteral() for 0.
    }

    if(a == nullptr) {
    }
    return 0;
}
