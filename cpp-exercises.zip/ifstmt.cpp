int main() {

    if(5 == 3) {
        int x = 3;
    } else {
        int x = 4;
    }

    return 0;
}
