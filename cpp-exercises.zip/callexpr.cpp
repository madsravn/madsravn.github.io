
int foo(int x);
int foo(int x, int y);
int baz(int x);
int baz(int x, int y);
class X {
    public: 
        int x(int y);
};

int main() {

    foo(5);
    foo(6, 5); // Match this one only
    baz(3);
    baz(3,5);
    X x;
    x.x(6);

    return 0;
}
